import React, { useState } from 'react';
import {
    Grid,
    Menu,
    Avatar,
    AppBar,
    Toolbar,
    IconButton,
    Typography,
    makeStyles,
} from '@material-ui/core';
import { Menu as MenuIcon } from '@material-ui/icons';

const useStyles = makeStyles(theme => ({
    appBar: {
        color: '#666666',
        background: '#ffffff',
        borderBottom: '1px solid rgba(0, 0, 0, 0.12)',
        boxShadow: 'none',
    },
    toolbar: {
        marginLeft: 64,
        [theme.breakpoints.down('sm')]: {
            marginLeft: 0,
        },
    },
    icon: {
        display: 'none',
        [theme.breakpoints.down('sm')]: {
            display: 'flex',
        },
    },
}));

const NavigationBar = ({ handleDrawerOpen }) => {
    const classes = useStyles();
    const [open, setOpen] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null);

    const handleOpen = event => setAnchorEl(event.currentTarget);
    const handleClose = () => setAnchorEl(null);

    return (
        <AppBar
            position="fixed"
            className={classes.appBar}
        >
            <Toolbar className={classes.toolbar}>
                <Grid container alignItems="center">
                    <Grid item xs>
                        <IconButton
                            edge="start"
                            color="inherit"
                            aria-label="open drawer"
                            className={classes.icon}
                            onClick={handleDrawerOpen}
                        >
                            <MenuIcon />
                        </IconButton>
                        <Typography variant="h6" noWrap>
                            Dashboard
                        </Typography>
                    </Grid>
                    <Grid item>
                        <IconButton aria-controls="menu" aria-haspopup="true" onClick={handleOpen}>
                            <Avatar src="https://i.pravatar.cc/50" />
                        </IconButton>
                        <Menu
                            keepMounted
                            id="menu"
                            anchorEl={anchorEl}
                            open={Boolean(anchorEl)}
                            onClose={handleClose}
                        >
                            Menu
                        </Menu>
                    </Grid>
                </Grid>
            </Toolbar>
        </AppBar>
    );
};

export default NavigationBar;